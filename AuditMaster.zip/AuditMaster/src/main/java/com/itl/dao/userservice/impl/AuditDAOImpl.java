package com.itl.dao.userservice.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itl.dao.base.impl.JpaDAOImpl;
import com.itl.dao.userservicee.AuditDAO;
import com.itl.domain.entities.userservice.AuditConsumer;
import com.itl.exceptions.NGException;

@Repository("auditDAO")
public class AuditDAOImpl extends JpaDAOImpl<Long, AuditConsumer> implements AuditDAO{

	
	@Autowired
	EntityManagerFactory entityManagerFactory;

	@PersistenceContext(unitName = "PRODTECH")
	private EntityManager entityManager;
	
	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
		super.setEntityManager(entityManager);
	}

	@PostConstruct
	public void init() {
		super.setEntityManagerFactory(entityManagerFactory);
		super.setEntityManager(entityManager);
	}

	public EntityManagerFactory getEntityManagerFactory() {
		return entityManagerFactory;
	}

	public void setEntityManagerFactory(
			EntityManagerFactory entityManagerFactory) {
		this.entityManagerFactory = entityManagerFactory;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	
	@Override
	public AuditConsumer getPrimaryKey(Long Id) throws NGException {
		
		Map<String, Object> queryParams = new HashMap<String, Object>();
		queryParams.put("Id", Id);

		List<AuditConsumer> rMaaz = findByNamedQueryAndNamedParams("AuditConsumer.getId", queryParams);
		if (null == rMaaz) {
			return null;
		} else if (rMaaz != null && rMaaz.size() == 0) {
			return null;
		}
		return rMaaz.get(0);
	}



	

	
}
