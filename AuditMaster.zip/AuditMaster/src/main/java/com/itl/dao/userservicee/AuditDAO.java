package com.itl.dao.userservicee;

import javax.persistence.EntityManagerFactory;

import com.itl.dao.basee.JPADAO;
import com.itl.domain.entities.userservice.AuditConsumer;
import com.itl.exceptions.NGException;

public interface AuditDAO extends JPADAO<AuditConsumer, Long>  {
	
	public EntityManagerFactory getEntityManagerFactory();
	
	
	
	public AuditConsumer getPrimaryKey(Long Id) throws NGException; 
	
	






}
