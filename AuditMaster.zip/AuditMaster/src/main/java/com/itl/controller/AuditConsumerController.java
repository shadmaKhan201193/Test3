package com.itl.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.web.bind.annotation.RestController;

import com.itl.domain.entities.userservice.AuditConsumer;
import com.itl.service.userr.AuditService;
import com.itl.utils.OmniConstants;

@RestController
public class AuditConsumerController {

	@Autowired
	AuditService auditService;
	
	private final Logger logger = LoggerFactory.getLogger(AuditConsumerController.class);
	
	
	@KafkaListener(topics = OmniConstants.TOPIC_NAME_TEST, groupId = OmniConstants.GROUP_ID)
	public void consumeRequest(String messages) {
		AuditConsumer	auditMst = new AuditConsumer();
		String[] value= messages.split("\\|");
		
			  auditMst.setResponse1(value[0]);
			  auditMst.setResponse2(value[1]);
	        
		    Date dt = new Date();
			auditMst.setCreatedBy("login");
			auditMst.setCreatedDate(dt);
			auditMst.setCreatedTime(dt);
			auditMst.setLastModifiedBy("login");
			auditMst.setLastModifiedDate(dt);
			auditMst.setLastModifiedTime(dt);
			auditMst.setAuthStatus(OmniConstants.AUTH_AUTHORIZED);
			auditMst.setIsActive(1);
			AuditConsumer auditMstNew = auditService.saveOrUpdate("login", auditMst);
		
	}
	

//	
//	@KafkaListener(topics = AppConstants.TOPIC_NAME_TEST, groupId = AppConstants.GROUP_ID)
//	@PostMapping(value = "/usersRegister", consumes = "application/json", produces = "application/json")
//	public String consumeRequest(@RequestBody AuditVO auditUser) {
//
//		// CountryMst countryMst =
//		// countryService.getByCountryId(country.getCountryId());
//		AuditConsumer auditMst = auditService.getPrimaryKey(auditUser.getId());
//
//		if (null != auditMst) {
//
//			return "Failure.. Record already exists";
//		}
//
//		else {
//			auditMst = new AuditConsumer();
//			Date dt = new Date();
//			
//			auditMst.setCreatedBy("login");
//			auditMst.setCreatedDate(dt);
//			auditMst.setCreatedTime(dt);
//			auditMst.setLastModifiedBy("login");
//			auditMst.setLastModifiedDate(dt);
//			auditMst.setLastModifiedTime(dt);
//			auditMst.setAuthStatus(OmniConstants.AUTH_AUTHORIZED);
//			auditMst.setIsActive(1);
//
//			
//
//			AuditConsumer auditMstNew = auditService.saveOrUpdate("login", auditMst);
//			if (null != auditMstNew) {
//
//				return "Successfully saved record";
//			} else {
//
//				return "Failure while saving record";
//			}
//
//		}
//	}



}