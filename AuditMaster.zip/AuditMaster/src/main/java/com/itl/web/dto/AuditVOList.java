package com.itl.web.dto;

import java.util.List;

public class AuditVOList {
	
	private List<AuditVO> user;

	public List<AuditVO> getUser() {
		return user;
	}

	public void setUser(List<AuditVO> user) {
		this.user = user;
	}
	
	

}
