package com.itl.web.dto;

import com.itl.domain.entities.base.Base;

public class AuditVO extends Base{
	
	
	private String response1="" ;
	
	private String response2="";

	private String isActive="";
	
	private String authStatus="";

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getAuthStatus() {
		return authStatus;
	}

	public void setAuthStatus(String authStatus) {
		this.authStatus = authStatus;
	}

	public String getResponse1() {
		return response1;
	}

	public void setResponse1(String response1) {
		this.response1 = response1;
	}

	public String getResponse2() {
		return response2;
	}

	public void setResponse2(String response2) {
		this.response2 = response2;
	}
	


	

	
	

}
