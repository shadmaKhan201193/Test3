package com.itl.service.userr;

import java.util.List;
import com.itl.domain.entities.userservice.AuditConsumer;
import com.itl.exceptions.NGException;
import com.itl.service.basee.NGService;

public interface AuditService extends NGService{

	
	public AuditConsumer getPrimaryKey(Long Id) throws NGException;
	
	public AuditConsumer saveOrUpdate(String loginId, AuditConsumer entity) throws NGException;
	
	//public AuditConsumer getByUsername(String username) throws NGException;
	//public List<AuditConsumer> getByCustomerId(Long id) throws NGException;
}
