package com.itl.service.user.impl;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.persistence.EntityManager;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.itl.dao.basee.JPADAO;
import com.itl.dao.userservicee.AuditDAO;
import com.itl.domain.entities.userservice.AuditConsumer;
import com.itl.exceptions.NGException;
import com.itl.service.base.impl.NGServiceImpl;
import com.itl.service.userr.AuditService;

@Service("AuditService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = NGException.class)
public class AuditServiceImpl extends NGServiceImpl<Long, AuditConsumer> implements AuditService {


	@Autowired
	AuditDAO auditDAO;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostConstruct
	public void init() throws Exception {
		super.setDAO((JPADAO) auditDAO);
	}

	@PreDestroy
	public void destroy() {
	}
	
	@Override
	public void setEntityManagerOnDao(EntityManager entityManager) {
	

		auditDAO.setEntityManager(entityManager);
	}
	
	@Override
	public AuditConsumer getPrimaryKey(Long Id) throws NGException {
		
		if (Id == null)
			return null;
		AuditConsumer opStat = auditDAO.getPrimaryKey(Id);
		if (null == opStat) {
			return null;
		} else {
			return opStat;
		}
	}

	@Override
	public AuditConsumer saveOrUpdate(String loginId, AuditConsumer entity) throws NGException {
	
		
		AuditConsumer rMaaz = getPrimaryKey(entity.getId());
		try {
			if (null == rMaaz) {
				return super.saveOrUpdate(loginId, entity);
			} else {
				// ---> update mode
				AuditConsumer rmfa = rMaaz;
				Mapper mapper = new DozerBeanMapper();
				mapper.map(entity, rmfa);
				return super.saveOrUpdate(loginId, rmfa);
			}
		} catch (Exception e) {
		
			e.printStackTrace();
			
		}
		return null;
	}

	


	

}
