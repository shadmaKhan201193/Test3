package com.itl.domain.entities.userservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import com.itl.domain.entities.base.Base;

@Entity
//@Audited(auditParents = { Base.class })
	@NamedQueries({
//	@NamedQuery(name="UserMst.getByDeleted", query = "SELECT e FROM UserMst e WHERE e.isDeleted=:isDeleted"),
	@NamedQuery(name="AuditConsumer.getId", query = "SELECT e FROM AuditConsumer e WHERE e.id=:Id")
	//@NamedQuery(name="AuditConsumer.getByUsername", query = "SELECT e FROM AuditConsumer e WHERE e.username=:username")
	
})
public class AuditConsumer extends Base {
	
	
	private static final long serialVersionUID = -1L;


	@Column(nullable = false,length = 48)
	private String response1 ="";
	
	@Column(nullable = false,length = 48)
	private String response2 ="";
	
	@Column(nullable = true)
	private Integer isActive = 1;

	@Column(nullable = true, length = 8)
	private String authStatus="";

	public String getResponse1() {
		return response1;
	}

	public void setResponse1(String response1) {
		this.response1 = response1;
	}

	public String getResponse2() {
		return response2;
	}

	public void setResponse2(String response2) {
		this.response2 = response2;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public String getAuthStatus() {
		return authStatus;
	}

	public void setAuthStatus(String authStatus) {
		this.authStatus = authStatus;
	}

	@Override
	public String toString() {
		return "AuditConsumer [response1=" + response1 + ", response2=" + response2 + ", isActive=" + isActive
				+ ", authStatus=" + authStatus + "]";
	}

	
	
	
	
	
	
	
}
